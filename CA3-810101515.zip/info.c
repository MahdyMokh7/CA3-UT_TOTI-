#include<stdio.h>
#include<stdlib.h>
#include<string.h>


#define FALSE 0
#define TRUE 1


#ifndef CONTENT
#define CONTENT
typedef struct content content;
struct content{
    int post_id;
    int like;
    char* post;
    //char** who_liked;
    content* next;
};
#endif

#ifndef TOTI_USER
#define TOTI_USER
typedef struct toti_user toti_user;
struct toti_user {
    content* my_content;
    char* user_name;
    char* password;
    int num_of_posts;
    toti_user* next;
};
#endif

toti_user* info(toti_user** tail_users, toti_user** node_cur_users, toti_user* head_users) {
    int flag = 0;
    content* cur = ((**node_cur_users).my_content)->next;
    content* prev = (**node_cur_users).my_content;
    printf("Username: %s\n",(**node_cur_users).user_name);
    printf("password: %s\n", (**node_cur_users).password);
    while(cur != NULL) {
        printf("post: %s\n", cur->post);
        printf("post_id: %d\n", cur->post_id);
        printf("like: %d\n", cur->like);
        prev = cur;
        cur = cur->next;
        printf("\n");
        flag = 1;
    }
    if(flag == 0) {
        printf("you have no posts yet\n");
    }
    return *node_cur_users;
}