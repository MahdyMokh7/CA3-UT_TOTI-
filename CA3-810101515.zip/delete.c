#include<stdio.h>
#include<stdlib.h>
#include<string.h>


#define FALSE 0
#define TRUE 1


#ifndef CONTENT
#define CONTENT
typedef struct content content;
struct content{
    int post_id;
    int like;
    char* post;
    //char** who_liked;
    content* next;
};
#endif

#ifndef TOTI_USER
#define TOTI_USER
typedef struct toti_user toti_user;
struct toti_user {
    content* my_content;
    char* user_name;
    char* password;
    int num_of_posts;
    toti_user* next;
};
#endif

toti_user* delete(char* part2, toti_user** tail_users, toti_user** node_cur_users, toti_user* head_users) {
    content* cur = (**node_cur_users).my_content;
    content* prev = NULL;
    int flag = 0;
    while(cur != NULL) { 
            flag = 1;
            prev->next = cur->next;
            free(cur->post);
            free(cur);
             break;
        if(cur->post_id == atoi(part2)) { //the post_id we want is found and deleted
        }
        prev = cur;
        cur = cur->next;
    }
    if(flag == 0) {
        printf("You dont have that post_id\n");
    }
    else {
        (**node_cur_users).num_of_posts--;
        printf("post deleted successfuly\n");
    }
    return *node_cur_users;
}
