#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include"signup.h"
#include"login.h"
#include"post.h"
#include"like.h"
#include"logout.h"
#include"delete.h"
#include"info.h"
#include"find_user.h"


#define FALSE 0
#define TRUE 1


#ifndef CONTENT
#define CONTENT
typedef struct content content;
struct content{
    int post_id;
    int like;
    char* post;
    //char** who_liked;
    content* next;
};
#endif

#ifndef TOTI_USER
#define TOTI_USER
typedef struct toti_user toti_user;
struct toti_user {
    content* my_content;
    char* user_name;
    char* password;
    int num_of_posts;
    toti_user* next;
};
#endif

int decoder(int* flag_login, int num_last_part, char* command, char* part2, char* part3, toti_user* head_users, toti_user** node_cur_users, toti_user** tail_users) { /*finding witch command the user gave us and doing it*/
    if(strcmp("signup", command) == 0) { // check flag_login   //karaye printf har tabe toye tabee
        if(*flag_login == 1 || num_last_part != 3) {
            return FALSE;
        }
        else {
            toti_user* check = head_users->next;
            while (check != NULL) {
                if(strcmp(check->user_name, part2) == 0) {
                    printf("The username you picked is used\n");
                    return FALSE;
                }
                check = check->next;
            }
            *flag_login = 0;
            *node_cur_users = signup(part2, part3, tail_users, node_cur_users, head_users);
        }
    }
    else if(strcmp("login", command) == 0) {
        if(*flag_login == 1 || num_last_part != 3) {
            return FALSE;
        }
        else {
            *node_cur_users = login(part2, part3, tail_users, node_cur_users, head_users);
            if(*node_cur_users == head_users) {
                printf("The username or password is incorrect\n");
                return FALSE;
            }
            else {
                *flag_login = 1;
            }
        }
    }
    else if(strcmp("post", command) == 0) {
        if((*flag_login) == 0 || num_last_part < 2) {
            return FALSE;
        }
        else {
            *flag_login = 1;
            *node_cur_users = post(part2, part3, tail_users, node_cur_users, head_users);
        }
    }
    else if(strcmp("info", command) == 0) {
        if( num_last_part != 1) {
            return FALSE;
        }
        else {
            *flag_login = 1;
            *node_cur_users = info(tail_users, node_cur_users, head_users);
        }
    }
    else if(strcmp("like", command) == 0) {
        if(*flag_login == 0 || num_last_part != 3) {
            return FALSE;
        }
        else {
            *flag_login = 1;
            *node_cur_users = like(part2, part3, tail_users, node_cur_users, head_users);
        }
    }
    else if(strcmp("logout", command) == 0) {
        if(*flag_login == 0 || num_last_part != 1) {
            return FALSE;
        }
        else {
            *flag_login = 0;
            *node_cur_users = logout(tail_users, node_cur_users, head_users);
        }
    }
    else if(strcmp("delete", command) == 0) {
        if(*flag_login == 0 || num_last_part != 2) {
            return FALSE;
        }
        else {
            *flag_login = 1;
            *node_cur_users = delete(part2, tail_users, node_cur_users, head_users);
        }        
    }
    else if(strcmp("find_user", command) == 0) {
        if(*flag_login == 0 || num_last_part != 2) {
            return FALSE;
        }
        else {
            *flag_login = 1;
            *node_cur_users = find_user(part2, tail_users, node_cur_users, head_users);
        }
    }
    else {
        return FALSE;
    }
    return TRUE;
}  