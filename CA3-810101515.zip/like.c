#include<stdio.h>
#include<stdlib.h>
#include<string.h>


#define FALSE 0
#define TRUE 1


#ifndef CONTENT
#define CONTENT
typedef struct content content;
struct content{
    int post_id;
    int like;
    char* post;
    //char** who_liked;
    content* next;
};
#endif

#ifndef TOTI_USER
#define TOTI_USER
typedef struct toti_user toti_user;
struct toti_user {
    content* my_content;
    char* user_name;
    char* password;
    int num_of_posts;
    toti_user* next;
};
#endif

toti_user* like(char* part2, char* part3, toti_user** tail_users, toti_user** node_cur_users, toti_user* head_users) {
    toti_user* cur_user = head_users;
    toti_user* prev_user = NULL;
    int flag = 0; // this flag if it gets 1 means that we liked if 0 we didnt
    while(cur_user != NULL) { // finding the user that has the post we want to like
        if(strcmp(cur_user->user_name, part2) == 0) {
            content* cur_content = cur_user->my_content;
            content* prev_content = NULL;
            while (cur_content != NULL) { // finding the post that we want to like
                if(cur_content->post_id == atoi(part3)) {
                    cur_content->like++;   //the situtation that we have tekrari likes is not strengthened
                    flag = 1;
                    break;
                }
                prev_content = cur_content;
                cur_content = cur_content->next;
            }
            break;
        }
        prev_user = cur_user;
        cur_user = cur_user->next;
    }
    if(flag == 1) {
        printf("post liked successfuly\n");
    }
    else {
        printf("post didnt got liked\n");
    }
    return *node_cur_users;
}