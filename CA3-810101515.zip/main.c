#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include"command_getter.h"
#include"part2_getter.h"
#include"part3_getter.h"
#include"decoder.h"
#include"design.h"
#include"print_in_file.h"


#define FALSE 0
#define TRUE 1
#define MIN_ARRAY_LEN 2


/*...................
Author : Mahdy Mokhtari
Student's ID : 810101515
file : CA3
Date : 1401 / 10 / 11
....................*/


#ifndef CONTENT
#define CONTENT
typedef struct content content;
struct content{
    int post_id;
    int like;
    char* post;
    //char** who_liked;
    content* next;
};
#endif

#ifndef TOTI_USER
#define TOTI_USER
typedef struct toti_user toti_user;
struct toti_user {
    content* my_content;
    char* user_name;
    char* password;
    int num_of_posts;
    toti_user* next;
};
#endif


int main() {
    int flag_login = 0, counter = 0;
    design();
    toti_user** tail_users;
    tail_users = (toti_user**)malloc(sizeof(toti_user*));
    *tail_users = (toti_user*)malloc(sizeof(toti_user));
    if(tail_users == NULL) {
        printf("coulnt malloc in main\n");
    }
    toti_user** node_cur_users;
    node_cur_users = (toti_user**)malloc(sizeof(toti_user*));
    *node_cur_users = *tail_users;
    if(node_cur_users == NULL) {
        printf("coulnt malloc in main\n");
    }        
    toti_user* head_users;
    head_users = *tail_users;
    head_users->next = NULL;
    char *command, *part2, *part3;
    while(TRUE) {
        int num_last_part = 0, check_decoder = -1;
        command = command_getter(&num_last_part); /*getting the command*/
        if(num_last_part == 0) {  /*if we have more than one word we will put the second word in part2*/
            part2 = part2_getter(&num_last_part);
            if(num_last_part == 0) {  /*if we have more than 2 words we will get all the rest as a sentence in part3*/
                part3 = part3_getter(&num_last_part);                
            }
        }
        printf("command:%s  part2:%s  part3:%s  num_last_part:%d\n", command, part2, part3, num_last_part);
        check_decoder = decoder(&flag_login, num_last_part, command, part2, part3, head_users, node_cur_users, tail_users);
        if(check_decoder == FALSE) {
            printf("not a correct command\n");
        }
        fflush(stdin);
        if(counter != 0) {
            if(num_last_part == 3) {
                free(command), free(part2), free(part3);
            }
            else if(num_last_part == 2) {
                free(command), free(part2);
            }
            else {
                free(command);
            }
        }
        counter++;
        print_in_file(head_users);
    }
}