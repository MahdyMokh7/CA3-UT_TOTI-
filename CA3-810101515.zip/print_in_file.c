#include<stdio.h>
#include<stdlib.h>
#include<string.h>


#define FALSE 0
#define TRUE 1


#ifndef CONTENT
#define CONTENT
typedef struct content content;
struct content{
    int post_id;
    int like;
    char* post;
    //char** who_liked;
    content* next;
};
#endif

#ifndef TOTI_USER
#define TOTI_USER
typedef struct toti_user toti_user;
struct toti_user {
    content* my_content;
    char* user_name;
    char* password;
    int num_of_posts;
    toti_user* next;
};
#endif

void print_in_file(toti_user* head_users) {
    FILE* account = fopen("C:\\Users\\MahdyBeast\\OneDrive\\Desktop\\programing\\C1\\.vscode\\CA3\\account.txt", "w");
    FILE* post = fopen("C:\\Users\\MahdyBeast\\OneDrive\\Desktop\\programing\\C1\\.vscode\\CA3\\post.txt", "w");
    if(post == NULL || account == NULL) {
        printf("couldnt fopen\n");
        exit(0);
    }
    toti_user* cur_user = head_users->next;
    while(cur_user != NULL) {
        int check_1 = fprintf(account, "%s %s %d\n", cur_user->user_name, cur_user->password, cur_user->num_of_posts);
        if(check_1 < 0) {
            printf("couldnt fprintf account.\n");
        }
        content* cur_content = (cur_user->my_content)->next; //////////////////
        while(cur_content != NULL) {
            int check_2 = fprintf(post, "%s %s %d\n", cur_content->post, cur_user->user_name, cur_content->like);
            if(check_2 < 0) {
                printf("couldnt fprintf account.\n");
            }
            cur_content = cur_content->next;
        }
        cur_user = cur_user->next;
    }
    fclose(account);
    fclose(post);
}