#include<stdio.h>

char* command_getter(int*);