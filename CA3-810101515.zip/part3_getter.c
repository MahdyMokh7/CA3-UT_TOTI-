#include<stdio.h>
#include<stdlib.h>
#include<string.h>


#define FALSE 0
#define TRUE 1
#define MIN_ARRAY_LEN 2


#ifndef CONTENT
#define CONTENT
typedef struct content content;
struct content{
    int post_id;
    int like;
    char* post;
    //char** who_liked;
    content* next;
};
#endif

#ifndef TOTI_USER
#define TOTI_USER
typedef struct toti_user toti_user;
struct toti_user {
    content* my_content;
    char* user_name;
    char* password;
    int num_of_posts;
    toti_user* next;
};
#endif

char* part3_getter(int* num_last_part) {
    char* part3 = (char*)malloc(sizeof(char) * MIN_ARRAY_LEN);
    char temp;
    int malloc_size = MIN_ARRAY_LEN;
    if(part3 == NULL) {
        printf("couldnt malloc part3\n");
        exit(0);
    }
    while((temp = getchar()) != '\n') {
        part3 = realloc(part3, sizeof(char) * malloc_size);
        if(part3 == NULL) {
            printf("couldnt realloc part3\n");
            exit(0);
        }
        part3[malloc_size - 2] = temp;
        malloc_size++;
    }
    if(temp == '\n') {
        (*num_last_part) = 3;
    }
    part3[malloc_size - 2] = '\0';
    fflush(stdin); ///
    return part3;
}