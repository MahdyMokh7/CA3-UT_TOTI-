#include<stdio.h>
#include<stdlib.h>

void design(void) {
    system("cls");
    printf(".........................Hi, Wellcome to UT_TOTI...........................\n\nwrite your command...\n");
}