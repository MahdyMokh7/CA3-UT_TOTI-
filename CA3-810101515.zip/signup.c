#include<stdio.h>
#include<stdlib.h>
#include<string.h>


#define FALSE 0
#define TRUE 1


#ifndef CONTENT
#define CONTENT
typedef struct content content;
struct content{
    int post_id;
    int like;
    char* post;
    //char** who_liked;
    content* next;
};
#endif

#ifndef TOTI_USER
#define TOTI_USER
typedef struct toti_user toti_user;
struct toti_user {
    content* my_content;
    char* user_name;
    char* password;
    int num_of_posts;
    toti_user* next;
};
#endif

toti_user* signup(char* part2, char* part3, toti_user** tail_users, toti_user** node_cur_users, toti_user* head_users) {  //bayad begardi agar yeki hamin esmo dasht to node hamoon nmitone sign up kone
    int part2_size, part3_size;
    (**tail_users).next = (toti_user*)malloc(sizeof(toti_user));
    if((**tail_users).next == NULL) {
        printf("couldnt malloc signup\n");
    }/*writing the users information and saving it to signup*/
    *tail_users = (**tail_users).next;
    (**tail_users).next = NULL;
    part2_size = strlen(part2);
    part3_size = strlen(part3);
    (**tail_users).user_name = (char*)malloc(sizeof(char) * part2_size);
    (**tail_users).password = (char*)malloc(sizeof(char) * part3_size);
    if((**tail_users).password == NULL || (**tail_users).user_name == NULL) {
        printf("couldnt malloc in user or pass in signup\n");
        exit(0);
    }
    strcpy((**tail_users).user_name, part2); 
    strcpy((**tail_users).password, part3);
    (**tail_users).num_of_posts = 0;
    (**tail_users).my_content = (content*)malloc(sizeof(content));         
    ((**tail_users).my_content)->next = NULL;
    if((**tail_users).my_content == NULL) {
        printf("couldnt malloc my_content or who_liked in signup\n");
        exit(0);
    }
    printf("signed up successefully\n");
    return head_users;
}
