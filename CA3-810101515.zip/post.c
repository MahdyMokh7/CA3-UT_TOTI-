#include<stdio.h>
#include<stdlib.h>
#include<string.h>


#define FALSE 0
#define TRUE 1



#ifndef CONTENT
#define CONTENT
typedef struct content content;
struct content{
    int post_id;
    int like;
    char* post;
    //char** who_liked;
    content* next;
};
#endif

#ifndef TOTI_USER
#define TOTI_USER
typedef struct toti_user toti_user;
struct toti_user {
    content* my_content;
    char* user_name;
    char* password;
    int num_of_posts;
    toti_user* next;
};
#endif

toti_user* post(char* part2, char* part3, toti_user** tail_users, toti_user** node_cur_users, toti_user* head_users) {
    content* cur = (**node_cur_users).my_content;      
    content* prev = NULL;
    int flag = 0;
    if(cur->next == NULL) {
        flag = 1;
    }
    while (cur != NULL) {  //finding the first empty node in the posts linked list
        prev = cur;
        cur = cur->next;
    }/*adding the post to our content list*/
    (**node_cur_users).num_of_posts++;
    prev->next = (content*)malloc(sizeof(content));
    (prev->next)->next = NULL;
    (prev->next)->like = 0;
    if (flag == 1) {
        (prev->next)->post_id = 1;
    }
    else {
        (prev->next)->post_id = ((prev->post_id) + 1);
    }
    (prev->next)->post = (char*)malloc(sizeof(char) * (strlen(part2) + strlen(part3) + 1));     ///////
    strcpy((prev->next)->post, part2);
    strcat((prev->next)->post, " ");
    strcat((prev->next)->post, part3);
    return *node_cur_users;
}