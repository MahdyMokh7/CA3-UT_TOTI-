#include<stdio.h>
#include<stdlib.h>
#include<string.h>


#define FALSE 0
#define TRUE 1


#ifndef CONTENT
#define CONTENT
typedef struct content content;
struct content{
    int post_id;
    int like;
    char* post;
    //char** who_liked;
    content* next;
};
#endif

#ifndef TOTI_USER
#define TOTI_USER
typedef struct toti_user toti_user;
struct toti_user {
    content* my_content;
    char* user_name;
    char* password;
    int num_of_posts;
    toti_user* next;
};
#endif

toti_user* find_user(char* part2, toti_user** tail_users, toti_user** node_cur_users, toti_user* head_users) {
    toti_user* cur_user = head_users;
    toti_user* prev_user = NULL;
    while(cur_user != NULL) {
        if(strcmp(cur_user->user_name, part2) == 0) { //the username got matched and now we are printing its info
            printf("Username: %s\n", cur_user->user_name);
            int flag = 0;
            content* cur = (cur_user->my_content)->next;
            content* prev = cur_user->my_content;
            while(cur != NULL) {
                printf("post: %s\n", cur->post);
                printf("post_id: %d\n", cur->post_id);
                printf("like: %d\n", cur->like);
                prev = cur;
                cur = cur->next;
                printf("\n");
                flag = 1;
            }
            if(flag == 0) {
            printf("you have no posts yet\n");
            }
            break;
        }
        prev_user = cur_user;
        cur_user = cur_user->next;
    }
    return *node_cur_users;
}