#include<stdio.h>
#include<stdlib.h>
#include<string.h>


#define MIN_ARRAY_LEN 2


char* command_getter(int* num_last_part) {
    char* command = (char*)malloc(sizeof(char) * MIN_ARRAY_LEN);
    if(command == NULL) {
        printf("couldnt malloc comand\n");
        exit(0);
    }
    char temp;
    int malloc_size = MIN_ARRAY_LEN; 
    while(((temp = getchar()) != ' ') && (temp != '\n')) {
        command = realloc(command, sizeof(char) * malloc_size);
        if(command == NULL) {
            printf("couldnt realloc part3\n");
            exit(0);
        }
        command[malloc_size - 2] = temp;
        malloc_size++;
    }
    if(temp == '\n') {
        (*num_last_part) = 1;
    }
    command[malloc_size - 2] = '\0';
    return command;
}