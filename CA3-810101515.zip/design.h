#include<stdio.h>
#include<stdlib.h>

void design(void);